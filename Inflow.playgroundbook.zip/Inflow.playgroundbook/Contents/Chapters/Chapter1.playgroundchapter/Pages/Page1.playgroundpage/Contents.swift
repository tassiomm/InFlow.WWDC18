//: # Influence In Colors
//: by Tassio Marques
//: ___
/*:
 ### The impact of others on you
 
 Believe it or not, people have a huge **impact** on how you act on an everyday basis.
 
 It's believed that a fair part of who you are, how you act and your decisions is a result of who you have around you.
 
 It's amazing. You can learn so much from people! Even if you think you don't. **Pay Attention!**
 
 This playground is about these connections. Leverage the best of what people around you have to offer.
 ___
 */
//: ### I'm feeling it...
//: ![poster](paletteposter.png)

/*:
 ### Let's play!
 
 It's quite simple. For this part, let's see how our friend in the center is affected by others. You can:
 
 - Choose a color in the palette
 - Then, tap anywhere in the screen to add a friend
 - If you want to remove all friends, try tapping on the circle in the center.
 - Have fun! Enjoy the power of colors!
 */
//#-hidden-code
import PlaygroundSupport

func choosePalette(_ kind: PaletteKind) {
    print(GameData.shared.palette.kind)
    GameData.shared.palette.changePalette(to: kind)
    print(GameData.shared.palette.kind)
    
    let page = PlaygroundPage.current
    if let proxy = page.liveView as? PlaygroundRemoteLiveViewProxy {
        proxy.send(.string(kind.rawValue))
    }
}
//#-end-hidden-code

/*:
 * Callout(Wanna try new colors?):
 You can change the visual! See the cool colors you can get with different palettes. Choose one, and hit run!
 */
choosePalette(/*#-editable-code*/.wwdc/*#-end-editable-code*/)

//: When you're done, we can move to next experience: [Influencing others](@next)
