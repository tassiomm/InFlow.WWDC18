//: # Influence In Colors
//: by Tassio Marques
//: ___
/*:
 ### The impact you cause on others
 
 
 As important as it might be having the right people by your side, are you inspiring people around you? Leave your footprint in the best way possible. Inspire people to be the best version of themselves!
 */

//:### Let's try?
//:
//: Here you'll be able to:
//:
/*:
 - Choose a color in the palette
 - Tap the friend in the center
 - See how the color affects the surroundings...
 - Go crazy! Tap the friends to remove them!
 */
//#-hidden-code
import PlaygroundSupport

func choosePalette(_ kind: PaletteKind) {
    print(GameData.shared.palette.kind)
    GameData.shared.palette.changePalette(to: kind)
    print(GameData.shared.palette.kind)
    
    let page = PlaygroundPage.current
    if let proxy = page.liveView as? PlaygroundRemoteLiveViewProxy {
        proxy.send(.string(kind.rawValue))
    }
}
//#-end-hidden-code

/*:
 * Callout(Remember the palettes?):
 See the cool results you can get with new colors. Choose one, and hit run!
 */
choosePalette(/*#-editable-code*/.vibes/*#-end-editable-code*/)
/*:
 
 ### Thank you!
 
 I hope you enjoyed the experience.
 
 I dedicate this playground for those who are yet to find their way. In life, college, work... I promisse it get better. Help is on the way.
 ___
 **"There are so many special people in the world"**
 
 Boa Sorte (Vanessa da Mata)
 ___
 And remember: enjoy the ride! Bye!!!
 */
