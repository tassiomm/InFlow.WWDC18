//
//  SpriteNode.swift
//  THEPlayground
//
//  Created by Tassio Moreira Marques on 24/03/2018.
//  Copyright © 2018 Tassio Marques. All rights reserved.
//

import SpriteKit

public class SpriteNode: SKSpriteNode {
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    public required override init(texture: SKTexture!, color: UIColor, size: CGSize) {
        super.init(texture: texture, color: color, size: size)
    }
    
    public convenience init(color: UIColor, size: CGSize, pos: CGPoint) {
        self.init(color: color, size: size)
        anchorPoint = CGPoint(x: 0.0, y: 0.0)
        self.position = pos
    }
}
