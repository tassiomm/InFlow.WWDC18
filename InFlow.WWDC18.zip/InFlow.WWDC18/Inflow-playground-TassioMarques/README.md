# Influence In Colors

Present in the assets folder are all the assets needed for the playground. By default you don't need to include them in the .playgroundbook (they are also there, in the resources folder). It's for safety.

Enjoy!

## Requirements 

iOS 10.0 or later; Swift Playgrounds 1.0 or later
