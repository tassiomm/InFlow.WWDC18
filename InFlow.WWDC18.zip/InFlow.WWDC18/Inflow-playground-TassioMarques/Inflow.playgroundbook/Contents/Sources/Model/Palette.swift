//
//  PalletColor.swift
//  THEPlayground
//
//  Created by Tassio Moreira Marques on 24/03/2018.
//  Copyright © 2018 Tassio Marques. All rights reserved.
//

import UIKit

public enum PaletteKind: String {
    case rgb
    case cmyk
    case wwdc
    case vibes
    case firefly
}

public class Palette {
    public var kind: PaletteKind
    private var colors: [Color]!
    
    init(kind: PaletteKind) {
        self.kind = kind
        updatePalette()
    }
    
    public func countColors() -> Int {
        return colors.count
    }
    
    public func getColor(at index: Int) -> Color? {
        if index < 0 || index >= colors.count {
            return nil
        } else {
            return colors[index]
        }
    }
    
    public func changePalette(to kind: PaletteKind) {
        self.kind = kind
        updatePalette()
    }
    
    public func updatePalette() {
        colors = []
        
        switch kind {
        case .rgb:
            colors.append(Color(color: .red, name: "Red"))
            colors.append(Color(color: .green, name: "Green"))
            colors.append(Color(color: .blue, name: "Blue"))
            colors.append(Color(color: UIColor(red: 240/255, green: 240/255, blue: 240/255, alpha: 1.0), name: "Light"))
            colors.append(Color(color: UIColor(red: 30/255, green: 30/255, blue: 30/255, alpha: 1.0), name: "Dark"))
        case .cmyk:
            colors.append(Color(color: .cyan, name: "Cyan"))
            colors.append(Color(color: .magenta, name: "Magenta"))
            colors.append(Color(color: .yellow, name: "Yellow"))
            colors.append(Color(color: .black, name: "Black"))
        case .wwdc:
            colors.append(Color(color: UIColor(red: 59/255, green: 63/255, blue: 66/255, alpha: 1.0), name: "W"))
            colors.append(Color(color: UIColor(red: 96/255, green: 100/255, blue: 103/255, alpha: 1.0), name: "W"))
            colors.append(Color(color: UIColor(red: 182/255, green: 184/255, blue: 186/255, alpha: 1.0), name: "D"))
            colors.append(Color(color: UIColor(red: 231/255, green: 235/255, blue: 238/255, alpha: 1.0), name: "C"))
        case .vibes:
            colors.append(Color(color: UIColor(red: 95/255, green: 15/255, blue: 64/255, alpha: 1.0), name: "V"))
            colors.append(Color(color: UIColor(red: 153/255, green: 3/255, blue: 30/255, alpha: 1.0), name: "I"))
            colors.append(Color(color: UIColor(red: 251/255, green: 139/255, blue: 36/255, alpha: 1.0), name: "B"))
            colors.append(Color(color: UIColor(red: 227/255, green: 100/255, blue: 20/255, alpha: 1.0), name: "E"))
            colors.append(Color(color: UIColor(red: 15/255, green: 76/255, blue: 92/255, alpha: 1.0), name: "S"))
        case .firefly:
            colors.append(Color(color: UIColor(red: 255/255, green: 251/255, blue: 12/255, alpha: 1.0), name: "F"))
            colors.append(Color(color: UIColor(red: 254/255, green: 232/255, blue: 42/255, alpha: 1.0), name: "F"))
            colors.append(Color(color: UIColor(red: 14/255, green: 47/255, blue: 185/255, alpha: 1.0), name: "L"))
            colors.append(Color(color: UIColor(red: 2/255, green: 2/255, blue: 64/255, alpha: 1.0), name: "Y"))
        }
    }
}
