//
//  GameData.swift
//  THEPlayground
//
//  Created by Tassio Moreira Marques on 24/03/2018.
//  Copyright © 2018 Tassio Marques. All rights reserved.
//

import Foundation
import SpriteKit

public enum Orientation {
    case portrait
    case landscape
}

public enum GameMode {
    case pageA
    case pageB
}

public class GameData {
    public static var shared = GameData()
    
    public var palette: Palette = Palette(kind: .rgb)
    public var gameMode: GameMode = .pageA
    
    public var countColors : Int {
        return GameData.shared.palette.countColors()
    }
    
    public var currentIndexColor : Int = -1
    
    public var sectionWidth: CGFloat {
        return (Consts.Palette.width / CGFloat(countColors)) - ((Consts.Palette.Section.space * CGFloat(countColors - 1)) / CGFloat(countColors))
    }
    
    public var colorWidth: CGFloat {
        return sectionWidth - (Consts.Palette.Section.colorOffSet * 2)
    }
    
    public lazy var isFriendsAddEnabled: Bool = (GameData.shared.mode() == .pageA) ? true : false
    
    public func mode() -> GameMode {
        return gameMode
    }
    
    public func changeMode(mode: GameMode) {
        self.gameMode = mode
    }
}

