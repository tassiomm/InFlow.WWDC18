//
//  Color.swift
//  THEPlayground
//
//  Created by Tassio Moreira Marques on 24/03/2018.
//  Copyright © 2018 Tassio Marques. All rights reserved.
//

import SpriteKit

public struct Color {
    public let color: UIColor!
    public let name: String!
    
    init(color: UIColor, name: String) {
        self.color = color
        self.name = name
    }
}
