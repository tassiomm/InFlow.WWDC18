import Foundation
import PlaygroundSupport
import UIKit
import SpriteKit

public class GameViewController: UIViewController, PlaygroundLiveViewMessageHandler {
    static let shared = GameViewController()
    private var sceneOnScreen: GameScene?
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        view = SKView(frame: CGRect(x:0.0 , y: 0.0, width: UIScreen.main.nativeBounds.width, height: UIScreen.main.nativeBounds.height))
        present()
    }
    
    public func present() {
        let scene = GameScene.shared
        scene.scaleMode = .aspectFill
        sceneOnScreen = scene
        (view as? SKView)?.presentScene(scene)
    }
    
    public func receive(_ message: PlaygroundValue) {
        switch message {
            case let .string(text):
                if let kind = PaletteKind(rawValue: text) {
                    sceneOnScreen?.changePaletteAnimation(to: kind)
                }
            default:
                return
        }
    }
    
    public override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if UIScreen.main.bounds.width < UIScreen.main.bounds.height {
            print("Portrait")
            GameScene.shared.updatePositionPalette(orientation: .portrait)
        } else {
            print("Landscape")
            GameScene.shared.updatePositionPalette(orientation: .landscape)
        }
    }
}
