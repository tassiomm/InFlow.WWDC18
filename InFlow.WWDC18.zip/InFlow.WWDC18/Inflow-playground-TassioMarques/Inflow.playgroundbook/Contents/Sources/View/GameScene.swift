//
//  GameScene.swift
//  THEPlayground
//
//  Created by Tassio Moreira Marques on 24/03/2018.
//  Copyright © 2018 Tassio Marques. All rights reserved.
//

import SpriteKit
import GameplayKit
import PlaygroundSupport

public class GameScene: SKScene {
    public static var shared = GameScene()
    
    private var palette: PaletteNode!
    private var centerNode: CenterNode!
    
    private var friends: [FriendNode] = []
    private var idCount: Int = 0
    
    private var centerView: SKSpriteNode!
    
    private var isChangingPalette = false
    
    public required override init() {
        super.init(size: CGSize(width: UIScreen.main.nativeBounds.height, height: UIScreen.main.nativeBounds.width))
        backgroundColor = Consts.Scene.backgroundColor
        
        self.centerView = SKSpriteNode(color: .clear, size: CGSize(width: Consts.Scene.width, height: Consts.Scene.height))
        centerView.anchorPoint = CGPoint(x: 0.0, y: 0.0)
        self.centerView.position = CGPoint(x: UIScreen.main.nativeBounds.height/2 - centerView.size.width/2, y: UIScreen.main.nativeBounds.width/2 - centerView.size.height/2)
        
        addPallete()
        addCenterNode()
        
        addChild(centerView)
        
        switch GameData.shared.gameMode {
        case .pageB:
            runPageB()
        default:
            emptyFriends()
        }
        
        Player.shared.playBackground()
    }
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    public func touchDown(atPoint pos : CGPoint) {
        let position = CGPoint(x: pos.x - Consts.Scene.width/2, y: pos.y)
        if GameData.shared.isFriendsAddEnabled {
            if friends.count <= Consts.Circle.friendsCount {
                if addFriend(at: position) != nil {
                    updateCenterFromAllFriends()
                }
            }
        }
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchDown(atPoint: t.location(in: self)) }
    }
    
    public override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        if !isChangingPalette {
            if UIScreen.main.bounds.width < UIScreen.main.bounds.height {
                // "Portrait"
                updatePositionPalette(orientation: .portrait)
            } else {
                // "Landscape"
                updatePositionPalette(orientation: .landscape)
            }
        }
    }
    
    func runPageB() {
        addMultipleFriends(count: Consts.Circle.friendsCount)
    }
    
    // MARK: BEGIN. Operation for Gradient
    
    func createGradientForAllFriends(from position: CGPoint) {
        func lerp(distanceFromCenter: CGFloat, centerY: CGFloat, height: CGFloat) -> CGFloat {
            return distanceFromCenter/height
        }
        
        func getGradient(from a: UIColor, to b: UIColor, withFraction fraction: CGFloat) -> UIColor  {
            let rA = a.components()[0]
            let gA = a.components()[1]
            let bA = a.components()[2]
            
            let rB = b.components()[0]
            let gB = b.components()[1]
            let bB = b.components()[2]
            
            let red = (rB - rA) * (fraction + rA)
            let green = (gB - gA) * (fraction + gA)
            let blue = (bB - bA) * (fraction + bA)
            
            return UIColor(red: red, green: green, blue: blue, alpha: 1.0)
        }
        
        var maxDistance: CGFloat = 0
        for friend in friends {
            let distance = position.getDistance(to: friend.position)
            maxDistance = maxDistance < distance ? distance : maxDistance
        }
        
        let centerColor: UIColor = centerNode.fillColor
        
        var finalColor: UIColor?
        if centerColor.isDark() {
            finalColor = UIColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        } else {
            finalColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        }
        
        for friend in friends {
            let distance = position.getDistance(to: friend.position)
            let a = lerp(distanceFromCenter: distance, centerY: centerNode.position.y, height: maxDistance)
            friend.fillColor = getGradient(from: centerColor, to: finalColor!, withFraction: a)
        }
    }
    // MARK: END. Operation for Gradient
    
    // MARK: BEGIN. Add Elements To Screen
    func addMultipleFriends(count: Int) {
        GameData.shared.currentIndexColor = -1
        for _ in 0..<count {
            let randomX = Int(arc4random() % UInt32(Consts.Scene.width + 200))
            let randomY = Int(arc4random() % UInt32(Consts.Scene.height + 200))
            
            addFriend(at: CGPoint(x: randomX, y: randomY))
        }
    }
    
    func addPallete() {
        palette = PaletteNode(color: .clear, size: CGSize(width: Consts.Palette.width, height: Consts.Palette.height), position: Consts.Palette.position)
        palette.name = Consts.Palette.id
        self.centerView.addChild(palette)
    }
    
    func addCenterNode() {
        centerNode = CenterNode(radius: Consts.Circle.radiusCenter)
        self.centerView.addChild(centerNode)
    }
    
    func addFriend(at position: CGPoint) -> FriendNode? {
        if centerNode.isPerformingAction {
            return nil
        }
        
        let colorIndex = GameData.shared.currentIndexColor
        var currentColor: UIColor = UIColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        
        if GameData.shared.gameMode == .pageA {
            if let color = GameData.shared.palette.getColor(at: colorIndex) {
                currentColor = color.color
            } else {
                return nil
            }
        }
        
        let friend = FriendNode(radius: Consts.Circle.radiusFriend, idIndex: idCount, color: currentColor, pos: position)
        friends.append(friend)
        centerView.addChild(friend)
        
        idCount += 1
        
        return friend
    }
    // MARK: END. Add Elements To Screen
    
    // MARK: BEGIN. Screen updates
    func emptyFriends() {
        for friend in friends {
            friend.removeFromParent()
        }
        friends = []
        centerNode.fillColor = .white
    }
    
    func updateCenterFromAllFriends() {
        var redSum: CGFloat = 0.0
        var greenSum: CGFloat = 0.0
        var blueSum: CGFloat = 0.0
        
        var newColor = UIColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        if !friends.isEmpty {
            for friend in friends {
                redSum += friend.fillColor.components()[0]
                greenSum += friend.fillColor.components()[1]
                blueSum += friend.fillColor.components()[2]
            }
            
            let count = CGFloat(friends.count)
            newColor = UIColor(red: redSum/count, green: greenSum/count, blue: blueSum/count, alpha: 1.0)
        }
        centerNode.removeAction(forKey: Consts.colorChangeActionKey)
        let changeColorAction = SKAction.shapeColorChangeAction(from: centerNode.fillColor, to: newColor, withDuration: 2.0)
        centerNode.run(changeColorAction, withKey: Consts.colorChangeActionKey)
    }
    
    public func changePaletteAnimation(to kind: PaletteKind) {
        isChangingPalette = true
        
        emptyFriends()
        if GameData.shared.gameMode == .pageB {
            runPageB()
        }
        
        let moveOut = SKAction.moveTo(y: Consts.Scene.height, duration: 0.5)
        let lastPositionY = self.palette.position.y
        
        palette.run(moveOut, completion: {
            () in
            self.palette.removeFromParent()
            GameData.shared.palette.changePalette(to: kind)
            self.addPallete()
            self.palette.position.y = Consts.Scene.height
            let moveDown = SKAction.moveTo(y: lastPositionY, duration: 0.5)
            self.palette.run(moveDown, completion: {() in self.isChangingPalette = false})
        })
    }
    
    public func updatePositionPalette(orientation: Orientation) {
        switch orientation {
        case .portrait:
            self.palette.position = Consts.Palette.positionPortrait
        case .landscape:
            self.palette.position = Consts.Palette.position
        }
    }
    
    // MARK: END. Screen updates
}
