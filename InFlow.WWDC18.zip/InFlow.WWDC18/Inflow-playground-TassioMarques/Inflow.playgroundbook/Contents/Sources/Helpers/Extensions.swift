//
//  Extensions.swift
//  THEPlayground
//
//  Created by Tassio Moreira Marques on 26/03/2018.
//  Copyright © 2018 Tassio Marques. All rights reserved.
//

import SpriteKit
import UIKit

extension SKScene {
    var center: CGPoint { return CGPoint(x: size.width / 2, y: size.height / 2) }
}

extension UIColor {
    func isDark() -> Bool {
        let components = self.components()
        
        let colorBrightness: CGFloat = (components[0] * 0.299) + (components[1] * 0.587) + (components[2] * 0.114);
        if (colorBrightness < 0.5) {
            return true
        } else {
            return false
        }
    }
    
    func components() -> [CGFloat] {
        var comp = self.cgColor.components!
        if comp.count < 4 {
            comp.insert(comp[0], at: 0)
            comp.insert(comp[0], at: 0)
        }
        return comp
    }
}

extension SKAction {
    public static func shapeColorChangeAction(from fromColor: UIColor, to toColor: UIColor, withDuration duration: TimeInterval) -> SKAction {
        func lerp(a: CGFloat, b: CGFloat, fraction: CGFloat) -> CGFloat {
            return (b - a) * fraction + a
        }
        
        let fromComp = fromColor.components()
        let toComp = toColor.components()
        let durationCGFloat = CGFloat(duration)
        return SKAction.customAction(withDuration: duration, actionBlock: { (node, elapsedTime) -> Void in
            let fraction = elapsedTime / durationCGFloat
            let transColor = UIColor(red: lerp(a: fromComp[0], b: toComp[0], fraction: fraction),
                                     green: lerp(a: fromComp[1], b: toComp[1], fraction: fraction),
                                     blue: lerp(a: fromComp[2], b: toComp[2], fraction: fraction),
                                     alpha: lerp(a: fromComp[3], b: toComp[3], fraction: fraction))
            (node as! SKShapeNode).fillColor = transColor
        })
    }
}

extension CGPoint {
    public func getDistance(to point: CGPoint) -> CGFloat {
        let xpow = pow(self.x - point.x, 2)
        let ypow = pow(self.y - point.y, 2)
        
        return CGFloat(sqrt(xpow + ypow))
    }
}
