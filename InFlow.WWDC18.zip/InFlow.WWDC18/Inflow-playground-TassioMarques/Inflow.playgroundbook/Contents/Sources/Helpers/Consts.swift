//
//  Consts.swift
//  THEPlayground
//
//  Created by Tassio Moreira Marques on 24/03/2018.
//  Copyright © 2018 Tassio Marques. All rights reserved.
//

import SpriteKit

public struct Consts {
    public static let fontName = "HelveticaNeue-Light"
    public static let colorChangeActionKey = "colorChangeActionKey"
    
    public struct Scene {
        public static let width: CGFloat = UIScreen.main.nativeBounds.height * 0.5
        public static let height: CGFloat = UIScreen.main.nativeBounds.width
        public static let offSet: CGFloat = 20
        
        public static let backgroundColor: UIColor = UIColor(red: 50/255, green: 50/255, blue: 50/255, alpha: 1)
    }
    
    public struct Palette {
        public static let id = "palette"
        
        public static let width: CGFloat = Scene.width - (Scene.offSet * 2)
        public static let height: CGFloat = Scene.height * 0.16
        public static let offSet: CGFloat = 50
        public static let position: CGPoint = CGPoint(x: Scene.offSet, y: Scene.height - height - offSet)
        public static let positionPortrait: CGPoint = CGPoint(x: Scene.offSet, y: Scene.height - height - offSet * 2.5)
        
        public struct Section {
            public static let id = "section-"
            
            public static let space: CGFloat = 10.0
            
            public static let backgroundColor: UIColor = .white
            public static let selectedColor: UIColor = UIColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 0.3)
            
            public static let colorOffSet: CGFloat = 7
            public static let colorHeight: CGFloat = Palette.height * 0.65
            
            public static let labelFontSize: CGFloat = Palette.height * 0.16
        }
    }
    
    public struct Circle {
        public static let centerId = "center"
        public static let friendId = "friend-"
        
        public static let radiusCenter: CGFloat = GameData.shared.mode() == .pageA ? 60.0 : 50.0
        public static let radiusFriend: CGFloat = GameData.shared.mode() == .pageA ? radiusCenter * 0.64 : radiusCenter * 0.5
        
        public static let physicBodyCenterRadius: CGFloat = GameData.shared.mode() == .pageA ? radiusCenter * 1.6 : radiusCenter * 1.4
        public static let gravityStrength: Float = 1000
        
        public static let friendsCount = GameData.shared.mode() == .pageA ? 210 : 330
    }
}

