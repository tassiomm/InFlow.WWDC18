//
//  Player.swift
//  THEPlayground
//
//  Created by Tassio Moreira Marques on 26/03/2018.
//  Copyright © 2018 Tassio Marques. All rights reserved.
//

import AVFoundation

public class Player {
    public static var shared = Player()
    private var audioPlayer: AVAudioPlayer?
    
    public func playBackground() -> Bool {
        if let path = Bundle.main.path(forResource: "interactionincolors", ofType: "m4a") {
            audioPlayer = try? AVAudioPlayer(contentsOf: URL(fileURLWithPath: path))
            audioPlayer?.setVolume(0.6, fadeDuration: 0)
            audioPlayer?.numberOfLoops = -1
            audioPlayer?.prepareToPlay()
            audioPlayer?.play()
            audioPlayer?.setVolume(0.1, fadeDuration: 1)
            return true
        } else {
            return false
        }
    }
}
