//
//  FriendNode.swift
//  THEPlayground
//
//  Created by Tassio Moreira Marques on 24/03/2018.
//  Copyright © 2018 Tassio Marques. All rights reserved.
//

import SpriteKit

class FriendNode: SKShapeNode {
    public convenience init(radius: CGFloat, idIndex: Int, color: UIColor, pos: CGPoint) {
        self.init(circleOfRadius: radius)
        
        name = Consts.Circle.friendId + "\(idIndex)"
        fillColor = color
        position = pos
        
        strokeColor = .white
        physicsBody = SKPhysicsBody(circleOfRadius: radius)
        physicsBody?.affectedByGravity = true
        physicsBody?.restitution = 0.0
        
        zPosition = 0
        
        isUserInteractionEnabled = GameData.shared.gameMode == .pageB
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.removeFromParent()
    }
}
