//
//  CircleNode.swift
//  THEPlayground
//
//  Created by Tassio Moreira Marques on 24/03/2018.
//  Copyright © 2018 Tassio Marques. All rights reserved.
//

import SpriteKit

class CenterNode: SKShapeNode {
    private var isScaling = false
    private var gravityField: SKFieldNode!
    
    public var isPerformingAction = false
    
    public convenience init(radius: CGFloat) {
        self.init(circleOfRadius: radius)
        name = Consts.Circle.centerId
        
        position = CGPoint(x: Consts.Scene.width/2, y: Consts.Scene.height/2 - Consts.Palette.height + Consts.Circle.radiusCenter)
        fillColor = .white
        
        physicsBody = SKPhysicsBody(circleOfRadius: CGFloat(Consts.Circle.physicBodyCenterRadius))
        physicsBody?.affectedByGravity = false
        physicsBody?.isDynamic = false
        physicsBody?.pinned = true
        physicsBody?.allowsRotation = true
        physicsBody?.friction = 0.9
        physicsBody?.restitution = 0.0
        
        zPosition = 1
        isUserInteractionEnabled = true
        
        isScaling = false
        addGravityField()
    }
    
    func addGravityField() {
        gravityField = SKFieldNode.radialGravityField()
        gravityField.position = CGPoint(x: 0.0, y: 0.0)
        gravityField.region = SKRegion(size: CGSize(width: Consts.Scene.width * 5, height: Consts.Scene.height * 5))
        gravityField.strength = Consts.Circle.gravityStrength
        gravityField.categoryBitMask = (0x1 << 0)
        gravityField.isEnabled = true
        
        addChild(gravityField)
    }
    
    public func scaleAndDeleteFriends() {
        if isScaling { return }
        
        isScaling = true
        removeAllActions()
        
        let scaleUp = SKAction.scale(by: 25, duration: 0.6)
        let reversedScaleUp = SKAction.reversed(scaleUp)()
        
        let closure = { () in
            GameScene.shared.emptyFriends()
            self.run(reversedScaleUp, completion: {
                () in
                self.fillColor = .white
                self.isScaling = false
            })
        }
        
        run(scaleUp, completion: closure)
    }
    
    public func removeGravityAndDeleteFriends() {
        if isPerformingAction {
            return
        }
        isPerformingAction = true
        gravityField.isEnabled = false
        SKAction.fadeAlpha(to: 0.7, duration: 2)
        let fadeOut = SKAction.fadeAlpha(to: 0.2, duration: 2)
        run(fadeOut) {
            let fadeIn = SKAction.fadeIn(withDuration: 1)
            self.run(fadeIn, completion: {
                GameScene.shared.emptyFriends()
                self.gravityField.isEnabled = true
                self.isPerformingAction = false
            })
        }
    }
    
    public func createGradientInFriends() {
        let index = GameData.shared.currentIndexColor
        if index >= 0 {
            
            if let color = GameData.shared.palette.getColor(at: index) {
                fillColor = color.color
            }
            GameScene.shared.createGradientForAllFriends(from: position)
        }
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if GameData.shared.gameMode == .pageA {
            removeGravityAndDeleteFriends()
        } else {
            createGradientInFriends()
        }
    }
}

