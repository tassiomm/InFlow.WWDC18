//
//  SectionNode.swift
//  THEPlayground
//
//  Created by Tassio Moreira Marques on 24/03/2018.
//  Copyright © 2018 Tassio Marques. All rights reserved.
//

import SpriteKit
import UIKit

class SectionNode: SpriteNode {
    private var index: Int!
    private var colorNode: SpriteNode!
    private var labelNode: SKLabelNode!
    var selected: Bool! {
        get {
            return (GameData.shared.currentIndexColor == index)
        }
        
        set(newValue) {
            if newValue {
                self.color = Consts.Palette.Section.selectedColor
                GameData.shared.currentIndexColor = index
            } else {
                self.color = Consts.Palette.Section.backgroundColor
                GameData.shared.currentIndexColor = -1
            }
        }
    }
    
    public convenience init(color: UIColor, size: CGSize, position: CGPoint, index: Int) {
        self.init(color: color, size: size, pos: position)
        
        name = Consts.Palette.Section.id + "\(index)"
        zPosition = 1
        isUserInteractionEnabled = true
        
        self.index = index
        selected = false
        addElements()
    }
    
    func addElements() {
        let n = GameData.shared.palette.getColor(at: index)?.name
        let c = GameData.shared.palette.getColor(at: index)?.color
        
        labelNode = SKLabelNode(text: n)
        labelNode.fontName = Consts.fontName
        labelNode.fontSize = Consts.Palette.Section.labelFontSize
        labelNode.fontColor = .black
        labelNode.position = CGPoint(x: self.size.width/2, y: 10.0)
        addChild(labelNode)
        
        let colorSize = CGSize(width: GameData.shared.colorWidth, height: Consts.Palette.Section.colorHeight)
        let colorY = self.size.height - colorSize.height - Consts.Palette.Section.colorOffSet
        colorNode = SpriteNode(color: c!, size: colorSize, pos: CGPoint(x: Consts.Palette.Section.colorOffSet, y: colorY))
        
        addChild(colorNode)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        updateSections()
        selected = !selected
    }
    
    func updateSections() {
        for i in 0..<GameData.shared.countColors {
            if let p = parent?.childNode(withName: Consts.Palette.Section.id + "\(i)") as? SectionNode {
                p.selected = false
            }
        }
    }
}

