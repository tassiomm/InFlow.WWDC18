//
//  PalletSpriteNode.swift
//  THEPlayground
//
//  Created by Tassio Moreira Marques on 24/03/2018.
//  Copyright © 2018 Tassio Marques. All rights reserved.
//

import SpriteKit

class PaletteNode: SpriteNode {
    public var Sections: [SectionNode] = []
    
    public convenience init(color: UIColor, size: CGSize, position: CGPoint) {
        self.init(color: color, size: size, pos: position)
        
        isUserInteractionEnabled = true
        zPosition = 1
        
        addSections()
    }
    
    public func addSections() {
        print("\(GameData.shared.countColors)")
        for index in 0..<GameData.shared.countColors {
            let SectionX = (CGFloat(index) * GameData.shared.sectionWidth) + (CGFloat(index) * Consts.Palette.Section.space)
            let Section = SectionNode(color: Consts.Palette.Section.backgroundColor, size: CGSize(width: GameData.shared.sectionWidth, height: Consts.Palette.height), position: CGPoint(x: SectionX, y: 0.0), index: index)
            addChild(Section)
        }
    }
}

