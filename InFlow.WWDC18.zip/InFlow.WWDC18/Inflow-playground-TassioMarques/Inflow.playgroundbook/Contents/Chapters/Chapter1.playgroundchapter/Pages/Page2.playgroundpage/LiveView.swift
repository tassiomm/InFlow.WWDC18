import PlaygroundSupport
import SpriteKit
import Foundation
import UIKit

GameData.shared.changeMode(mode: .pageB)
GameData.shared.palette.changePalette(to: .vibes)

PlaygroundPage.current.liveView = GameViewController()

