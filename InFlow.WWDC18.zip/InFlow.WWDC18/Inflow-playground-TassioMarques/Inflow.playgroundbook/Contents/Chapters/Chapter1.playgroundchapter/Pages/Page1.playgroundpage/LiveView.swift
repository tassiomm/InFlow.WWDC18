import PlaygroundSupport
import SpriteKit
import Foundation
import UIKit

GameData.shared.changeMode(mode: .pageA)
GameData.shared.palette.changePalette(to: .wwdc)

PlaygroundPage.current.liveView = GameViewController()
